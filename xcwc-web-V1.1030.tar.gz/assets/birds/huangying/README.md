# 第一版小黄莺网页素材

来源：`/Users/beluga/Code/xcwc/小鸟资料库/小黄莺/小黄莺_开心.webp`。

选用“开心”作为默认角色，因为它是完整站姿、绿叶冠与黄绿配色清晰，适合小窝主角、头像、商品展示和打卡贴片。饥饿为趴地并带饭碗气泡，害羞带心形，大哭/生气/难受等具有明确情绪用途；第一版静态换图不批量预加载这些表情，也不把它们当同一站姿混用。

原资料库现行 WebP/PNG 均为 RGB 白底，不含透明通道。白底衍生直接等比缩小原图；头像补齐白色正方形以适配圆形头像，保留完整叶冠和脚。透明主角色/打卡贴片仅从单独复核的去背景衍生源导出，不用简单白色阈值误伤奶白色肚皮。

## 当前导出

| 文件 | 像素尺寸 | 大小 | 背景 |
| --- | --- | ---: | --- |
| happy-avatar-192.webp | 192 × 192 | 2.88 KB | 保留白底 |
| happy-card-400.webp | 400 × 329 | 10.19 KB | 保留白底 |
| happy-hero-640.webp | 640 × 526 | 75.21 KB | 透明 |
| happy-sticker-400.webp | 400 × 329 | 34.28 KB | 透明 |
| happy-avatar-transparent-192.webp | 192 × 158 | 10.58 KB | 透明 |

总计 **133.15 KB**。尺寸与压缩值会随复核透明源而变化，以 `asset-report.json` 为机器可读依据。WebP 为按用途缩放后的有损网页版本，不宣称原尺寸无损；白底原件 1,397,820 字节不直接作为小头像网络资源。

## 性能使用

- `happy-avatar-192.webp` 用于头像、切鸟列表等小尺寸场景；不把高清原图用于几十像素头像。
- `happy-card-400.webp` 用于白底商品图、静态展示。
- 若导出，`happy-hero-640.webp` 用于树屋/城市等透明主角色；`happy-sticker-400.webp` 用于打卡 Canvas 贴片；`happy-avatar-transparent-192.webp` 用于小型透明装饰/城市贴片，不替代保留白底的头像版本。
- 同一资源使用同一外链 URL，借用浏览器缓存；不要在多个页面重复 base64 内联。
- 首屏只加载当前所需的“开心”图，其他表情按实际交互需要再加载；不用一次预加载全目录。
- 原始库、历史版本及高清输入不复制到普通发布资源目录。本目录只存实际网页变体与说明。

## 重新生成

```sh
python3 scripts/prepare-huangying-assets.py
python3 scripts/prepare-huangying-assets.py --transparent-source /absolute/path/to/reviewed-cutout.png
```

脚本不修改源文件，不重绘角色，不改配色；使用 Lanczos 缩小、WebP `method=6` 编码，头像质量 80，其他变体质量 84。可选透明源必须含非全不透明 alpha。报告记录每个输入及输出的 SHA-256、字节和像素尺寸。
